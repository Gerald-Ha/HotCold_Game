﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GX_HotCold
{
    public partial class MainWindow : Window
    {
        private int remainingTries = 10; // Grid zum Klicken
        private int targetIndex;
        private Random random = new Random();
        private const int GridSize = 10;

        public MainWindow()
        {
            InitializeComponent();
            StartNewGame();
        }

        private void StartNewGame()
        {
            remainingTries = 10;    // Anzahl der versuche
            RemainingTries.Text = remainingTries.ToString();
            Display.Text = "";
            targetIndex = random.Next(100);

            // Grid zum Klicken
            ButtonGrid.Children.Clear();
            for (int i = 0; i < GridSize * GridSize; i++)
            {
                Button button = new Button
                {
                    Name = $"Button{i}",
                    Style = (Style)FindResource("GameButtonStyle"),
                    Tag = i
                };
                button.Click += Cell_Click;
                ButtonGrid.Children.Add(button);
            }
        }

        private void Cell_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                int index = (int)button.Tag;
                int distance = Math.Abs(index % GridSize - targetIndex % GridSize) + Math.Abs(index / GridSize - targetIndex / GridSize);

                if (index == targetIndex)
                {
                    button.Background = Brushes.White;
                    button.Content = "Gewonnen!";
                    ShowWinWindow();
                }
                else
                {
                    button.Background = Brushes.Red;
                    remainingTries--;
                    RemainingTries.Text = remainingTries.ToString();

                    if (distance >= 5)
                    {
                        Display.Text = "Kalt";
                    }
                    else if (distance >= 3)
                    {
                        Display.Text = "Warm";
                    }
                    else
                    {
                        Display.Text = "Sehr Warm";
                    }

                    if (remainingTries == 0)
                    {
                        EndGame("You Lose!");
                    }

                    button.IsEnabled = false;
                }
            }
        }

        private void ShowWinWindow()
        {
            WinWindow winWindow = new WinWindow();
            winWindow.Owner = this;
            winWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            winWindow.ShowDialog();
            StartNewGame();
        }

        private void EndGame(string message)
        {
            MessageBoxResult result = MessageBox.Show($"{message}\nWeiterspielen?", "Spiel beendet", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                StartNewGame();
            }
            else
            {
                Application.Current.Shutdown();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}